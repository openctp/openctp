MacOS行情API

支持MacOS 10.12以上操作系统。

文件包含静态库文件 libthostmduserapi.a 以及头文件
ThostFtdcMdApi.h ThostFtdcUserApiDataType.h ThostFtdcUserApiStruct.h。

文件夹libs里面包含了穿透式相关的加密库，这些库已包含在MacOS信息采集模块中，如果程序中使用了信息采集模块，不需要导入libs中的文件。
