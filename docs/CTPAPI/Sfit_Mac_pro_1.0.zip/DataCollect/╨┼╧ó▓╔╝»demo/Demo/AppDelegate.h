//
//  AppDelegate.h
//  Demo
//
//  Created by zhongkai.li on 2021/11/1.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

