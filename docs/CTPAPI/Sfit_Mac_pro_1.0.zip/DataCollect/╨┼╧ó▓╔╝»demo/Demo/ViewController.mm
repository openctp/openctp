//
//  ViewController.m
//  Demo
//
//  Created by zhongkai.li on 2021/11/1.
//

#import "ViewController.h"
#import "DataCollect.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    
    char *result = (char *) malloc(sizeof(char) * 270);
    int length = 0;
    NSLog(@"%s", CTP_GetDataCollectApiVersion());
//    int code = CTP_GetSystemInfoUnAesEncode(result, length);
    int code = CTP_GetSystemInfo(result, length);

    NSLog(@"length = %d",length);
    NSLog(@"code = %d", code);
    
    for (int i = 0; i < length; i++){
        printf("%d ", result[i]);
    }
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
