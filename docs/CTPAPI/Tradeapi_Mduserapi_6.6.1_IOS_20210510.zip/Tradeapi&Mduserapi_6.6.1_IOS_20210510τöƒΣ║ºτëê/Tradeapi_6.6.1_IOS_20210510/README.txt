1. 说明

本次发布版本包括交易api及信息采集模块。
交易api新增了下面两个查询接口：

///投资者风险结算持仓查询
virtual int ReqQryRiskSettleInvstPosition(CThostFtdcQryRiskSettleInvstPositionField *pQryRiskSettleInvstPosition, int nRequestID) = 0;

///风险结算产品查询
virtual int ReqQryRiskSettleProductStatus(CThostFtdcQryRiskSettleProductStatusField *pQryRiskSettleProductStatus, int nRequestID) = 0;

对投资者密码进行加密处理。

2. 开发环境要求

开发者需要配置Xcode开发环境，否则采集模块可能无法正常使用。

3. 操作系统要求

要求操作系统为iOS 8以上版本。

4. 应用权限配置

信息采集模块采集信息时，需要应用具备某些权限。若应用不具备某些权限，
可能会导致获取到对应的采集项为空。因此在使用信息采集模块前， 请使用者申请权限。
包括允许应用访问位置和访问网络权限。


5. 支持架构

目前SDK支持i386，x86_64，armv7s，arm64和armv7。

6. 如何使用API和采集模块

将交易api和行情api以及信息采集模块导入项目中。
添加需要用到的程序框架：CoreLocation.framework和CoreTelephony.framework。
在需要采集信息的地方，导入头文件IOSDataCollect.h，把实现文件的.m后缀改为.mm。


7. 常见问题：

 7.1. 信息采集模块获取信息失败；
请检查项目中是否引入了openssl静态库，采集模块包含了openssl静态库，可能会引起冲突，
解决方案：移除项目中的其他openssl静态库。

 7.2. 项目中引入行情API导致交易API无法正常使用；
是由于API版本不一致导致的，请使用同一个版本的交易API和行情API。






