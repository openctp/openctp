//
//  ViewController.m
//  信息采集Demo
//
//  Created by user on 2019/6/19.
//  Copyright © 2019年 user. All rights reserved.
//

#import "ViewController.h"
#import "IOSDataCollect.h"
#import <CoreLocation/CoreLocation.h>
@interface ViewController (){
    CLLocationManager *locationmanager;
}

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}
- (IBAction)getInfo:(id)sender {
    CTP_GetSystemInfo(^(char *pSystemInfo, int nLen, const char *errmsg) {
        if(errmsg != NULL){
            printf("%s\n", errmsg);
        } else {
            printf("获取用户加密信息成功\n");
        }
        
        NSMutableString *str = [[NSMutableString alloc] initWithCapacity:0];
        for (int i = 0; i < nLen; i ++) {
            [str appendString:[NSString stringWithFormat:@"%d, ", pSystemInfo[i]]];
        }
        self.textView.text = str;
    });
}

- (IBAction)getLocation:(id)sender {
    if ([CLLocationManager locationServicesEnabled]) {
        locationmanager = [[CLLocationManager alloc]init];
        [locationmanager requestWhenInUseAuthorization];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
