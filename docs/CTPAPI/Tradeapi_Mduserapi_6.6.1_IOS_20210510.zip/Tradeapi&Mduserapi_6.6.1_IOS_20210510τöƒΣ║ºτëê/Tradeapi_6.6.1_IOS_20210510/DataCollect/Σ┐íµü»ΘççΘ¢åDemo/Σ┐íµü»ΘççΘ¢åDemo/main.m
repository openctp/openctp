//
//  main.m
//  信息采集Demo
//
//  Created by user on 2019/6/19.
//  Copyright © 2019年 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
