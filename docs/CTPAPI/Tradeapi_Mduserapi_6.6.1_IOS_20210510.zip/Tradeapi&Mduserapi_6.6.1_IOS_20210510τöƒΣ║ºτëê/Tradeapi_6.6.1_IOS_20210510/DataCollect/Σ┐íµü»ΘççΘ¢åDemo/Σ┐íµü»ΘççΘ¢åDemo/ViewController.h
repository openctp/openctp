//
//  ViewController.h
//  信息采集Demo
//
//  Created by user on 2019/6/19.
//  Copyright © 2019年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

