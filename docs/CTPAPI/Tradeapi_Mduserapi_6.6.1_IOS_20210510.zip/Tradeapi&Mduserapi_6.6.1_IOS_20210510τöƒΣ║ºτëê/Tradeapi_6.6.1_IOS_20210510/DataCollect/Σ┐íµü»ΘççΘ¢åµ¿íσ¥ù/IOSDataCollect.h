/////////////////////////////////////////////////////////////////////////
///@system iOS信息采集模块
///@company 上海期货信息技术有限公司
///@file IOSDataCollect.h
///@brief 定义了信息采集模块客户端接口
///@history
///20190528    陈重阳        创建该文件
/////////////////////////////////////////////////////////////////////////

#ifndef IOSDataCollect_h
#define IOSDataCollect_h

/*
 pSystemInfo: 加密后的采集信息。
 nLen: 获取到的采集信息的长度，错误返回 -1。
 errmsg: 包含采集信息的错误信息。
 需要用户自己申请位置权限，否则无法获取位置信息。
 */

//中继模式，获取加密信息
void CTP_GetSystemInfo(void (^GetSystemInfo)(char * pSystemInfo, int nLen, const char* errmsg));
//直连模式，获取加密信息
void CTP_GetSystemInfoUnAesEncode(void (^GetSystemInfo)(char * pSystemInfo, int nLen, const char* errmsg));

#endif /* IOSDataCollect_h */
